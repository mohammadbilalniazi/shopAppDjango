# Centralized API Manager Documentation

## Overview

The centralized API Manager provides a single focal point for all API calls in the Django Shop Application, with unified response handling and toast message management.

## Features

✅ **Single Focal Point** - All API calls go through one centralized manager  
✅ **Unified Response Handling** - Consistent success/error handling  
✅ **Toast Notifications** - Beautiful success/error/warning/info messages  
✅ **CSRF Protection** - Automatic CSRF token handling  
✅ **Loading States** - Optional loading indicators  
✅ **Error Retry** - Built-in retry mechanism for failed requests  
✅ **Batch Operations** - Handle multiple API calls efficiently  
✅ **File Uploads** - Simplified file upload handling  
✅ **Form Submission** - Easy form handling with validation  

## Quick Start

### 1. Basic API Calls

```javascript
// GET Request
const users = await apiManager.get('/user/organization_user/get/', {
    messages: {
        success: 'Users loaded successfully',
        error: 'Failed to load users'
    }
});

// POST Request
const result = await apiManager.post('/user/organization_user/insert/', {
    username: 'newuser',
    email: 'user@example.com',
    organization: 1
}, {
    showLoading: true,
    messages: {
        success: 'User created successfully!',
        error: 'Failed to create user'
    }
});

// PUT Request
const updateResult = await apiManager.put('/user/update/123/', {
    first_name: 'Updated Name'
});

// DELETE Request  
const deleteResult = await apiManager.delete('/user/delete/123/', {
    messages: {
        success: 'User deleted successfully',
        error: 'Failed to delete user'
    }
});
```

### 2. Using API Endpoints Configuration

```javascript
// Use predefined endpoints from API_ENDPOINTS
const branches = await apiManager.get(API_HELPERS.branchesByOrganization(orgId));

const newBranch = await apiManager.post(API_ENDPOINTS.BRANCH.CREATE, branchData);

const product = await apiManager.get(API_ENDPOINTS.PRODUCT.LIST);
```

### 3. Form Submission

```javascript
// Simple form submission
const form = document.getElementById('user-form');
form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const result = await apiManager.submitForm(form, {
        messages: {
            success: 'Form submitted successfully!',
            error: 'Failed to submit form'
        },
        showLoading: true
    });
    
    if (result.success) {
        // Handle success
        window.location.href = '/success-page/';
    }
});
```

### 4. File Uploads

```javascript
// File upload
const fileInput = document.getElementById('file-input');
fileInput.addEventListener('change', async (e) => {
    const result = await apiManager.uploadFile(
        '/upload/endpoint/',
        e.target,
        { description: 'Product image' },
        {
            messages: {
                success: 'File uploaded successfully!',
                error: 'Failed to upload file'
            }
        }
    );
    
    if (result.success) {
        updateImagePreview(result.data.file_url);
    }
});
```

### 5. Toast Messages

```javascript
// Manual toast messages
apiManager.showToast('Operation completed', 'success');
apiManager.showToast('Warning: Check your input', 'warning');  
apiManager.showToast('Error occurred', 'error');
apiManager.showToast('Information message', 'info');

// Custom toast with title and duration
apiManager.showToast('Custom message', 'success', 'Custom Title', 8000);
```

## Available Files

### 1. `static/assets/js/api-manager.js`
Main API Manager class with all functionality

### 2. `static/assets/js/api-endpoints.js`  
Centralized configuration of all API endpoints

### 3. `static/assets/js/api-examples.js`
Comprehensive usage examples and helper functions

## API Manager Methods

### Core Methods
- `get(url, options)` - GET request
- `post(url, body, options)` - POST request  
- `put(url, body, options)` - PUT request
- `delete(url, options)` - DELETE request
- `patch(url, body, options)` - PATCH request

### Specialized Methods
- `submitForm(form, options)` - Submit HTML forms
- `uploadFile(url, fileInput, additionalData, options)` - File uploads
- `batch(requests)` - Multiple requests
- `requestWithRetry(url, options, maxRetries)` - Retry failed requests

### UI Methods
- `showToast(message, type, title, duration)` - Display toast notifications

## Response Format

All API calls return a consistent response format:

```javascript
// Success Response
{
    success: true,
    data: { /* API response data */ }
}

// Error Response
{
    success: false,
    error: "Error message",
    data: { /* Any additional error data */ }
}
```

## Options Object

```javascript
{
    // Custom success/error messages
    messages: {
        success: 'Custom success message',
        error: 'Custom error message'
    },
    
    // Show loading indicator
    showLoading: true,
    
    // Custom headers
    headers: {
        'Custom-Header': 'value'
    },
    
    // Other fetch options
    credentials: 'same-origin',
    cache: 'no-cache'
}
```

## Integration Examples

### Product Management
```javascript
// Load products
const products = await apiManager.get(API_ENDPOINTS.PRODUCT.LIST, {
    messages: { error: 'Failed to load products' }
});

// Update stock
const stockUpdate = await apiManager.post('/stock/update/', {
    product_id: 123,
    current_amount: 50,
    organization_id: 1
}, {
    showLoading: true,
    messages: {
        success: 'Stock updated successfully',
        error: 'Failed to update stock'
    }
});
```

### Branch Management
```javascript
// Create branch
const newBranch = await apiManager.post(API_ENDPOINTS.BRANCH.CREATE, {
    name: 'New Branch',
    organization_id: 1,
    address: 'Branch Address'
}, {
    showLoading: true,
    messages: {
        success: 'Branch created successfully!',
        error: 'Failed to create branch'
    }
});

// Toggle branch status
const toggleResult = await apiManager.post(
    API_HELPERS.branchToggleStatus(branchId)
);
```

### User Management
```javascript
// Search users
const searchResults = await apiManager.post('/user/organization_user/search/', {
    query: 'search term'
}, {
    messages: {
        error: 'Search failed. Please try again.'
    }
});

// Delete user
const deleteResult = await apiManager.delete(
    API_HELPERS.deleteUser(userId),
    {
        messages: {
            success: 'User deleted successfully',
            error: 'Failed to delete user'
        }
    }
);
```

## Error Handling

The API Manager provides automatic error handling with toast notifications, but you can also handle errors manually:

```javascript
const result = await apiManager.get('/some/endpoint');

if (!result.success) {
    console.error('API Error:', result.error);
    
    // Custom error handling based on error type
    if (result.error.includes('permission')) {
        // Handle permission errors
        redirectToLogin();
    } else if (result.error.includes('network')) {
        // Handle network errors
        showRetryOption();
    }
}
```

## Global Availability

The API Manager is globally available as:
- `window.apiManager` - Main API Manager instance
- `API_ENDPOINTS` - Endpoints configuration
- `API_HELPERS` - Helper functions for dynamic URLs

## Migration from Old Code

### Before (Old Pattern)
```javascript
let response = await call_shirkat("/stock/update/", "POST", JSON.stringify(formData));
if (response.status === 201 || response.status === 200) {
    message.innerHTML = "Success message";
} else {
    alert("Error: " + JSON.stringify(response.data));
}
```

### After (New Pattern)  
```javascript
const response = await apiManager.post('/stock/update/', formData, {
    showLoading: true,
    messages: {
        success: 'Stock updated successfully',
        error: 'Failed to update stock'
    }
});

if (response.success) {
    // Handle success - toast already shown
    updateUI(response.data);
}
```

## Benefits

1. **Consistency** - All API calls follow the same pattern
2. **Error Handling** - Unified error handling and user feedback  
3. **User Experience** - Beautiful toast notifications instead of alerts
4. **Maintainability** - Centralized API configuration
5. **Security** - Automatic CSRF protection
6. **Performance** - Built-in retry and batch operations
7. **Developer Experience** - Easy to use with helpful examples

## Toast Notification Types

- **Success** (Green gradient): `'success'`
- **Error** (Red gradient): `'error'` 
- **Warning** (Orange gradient): `'warning'`
- **Info** (Blue gradient): `'info'`

Each toast includes:
- Appropriate icon (✅❌⚠️ℹ️)
- Smooth animations
- Auto-dismiss after set duration
- Manual close button
- Responsive design
- Design system integration

---

**The API Manager is now the single focal point for all API communications in the Django Shop Application, providing unified response handling and beautiful user feedback through toast notifications.**