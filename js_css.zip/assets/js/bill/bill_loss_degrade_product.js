let data;
let product_data;
let purchasing_price_obj = {};
let purchased_price;

/**
 * Helper function to fetch and cache unit data.
 */
async function get_units() {
    const id = "all";
    const unit_url = `/units/${id}/`;
    let unit_data = localStorage.getItem("unit_data");

    if (!unit_data) {
        console.log("Fetching unit data...");
        let response = await call_shirkat(unit_url, 'GET');
        unit_data = response.data;
        localStorage.setItem("unit_data", JSON.stringify(unit_data));
    } else {
        unit_data = JSON.parse(unit_data);
    }
}

/**
 * Fetches products and updates local storage.
 */
async function get_products(organization = "all", change_price = true) {
    const url = `/products/`;
    let storedProductData = localStorage.getItem("product_data");

    if (storedProductData) {
        product_data = JSON.parse(storedProductData);
    } else {
        console.log("Fetching product data...");
        const postData={'organization_id':organization}
        let response = await call_shirkat(url, 'POST',postData);
        product_data = response.data;
        localStorage.setItem("product_data", JSON.stringify(product_data));
    }

    for (const key in product_data) {
        let product = product_data[key];
        if (product.product_detail) {
            purchasing_price_obj[product.id] = product.product_detail.purchased_price;
        } else {
            product_data[key]['product_detail'] = { selling_price: 0, purchased_price: 0, minimum_requirement: 0 };
            purchasing_price_obj[product.id] = 0;
        }
    }
    localStorage.setItem("purchasing_price_obj",JSON.stringify(purchasing_price_obj));
    localStorage.setItem("product_data", JSON.stringify(product_data));
    add_events_to_elements(change_price);
}

/**
 * Changes the price field based on the selected bill type.
 */
function change_price_field(item_db_id, index, bill_type_field) {
    const item_price = document.getElementsByClassName("item_price")[index];
    purchasing_price_obj = JSON.parse(localStorage.getItem("purchasing_price_obj"));
    item_price.value = purchasing_price_obj[parseInt(item_db_id)];
    generate_total_amount_bill();
}


/**
 * Adds event listeners to dynamically created elements.
 */
function add_events_to_elements(change_price = true) {
    console.log("Adding events to elements...");
    
    try {
        let item_amount = document.getElementsByClassName("item_amount");
        let item_price = document.getElementsByClassName("item_price");
        let return_qty = document.getElementsByClassName("return_qty");
        let bill_type = document.getElementById("bill_type");
        let item_name = document.getElementsByClassName("item_name");
        for (let i = 0; i < item_amount.length; i++) {
            item_amount[i].addEventListener("keyup", generate_total_amount_bill);
            return_qty[i].addEventListener("input", generate_total_amount_bill);
            item_name[i].addEventListener("change", e => change_price_field(e.target.value, i, bill_type));
            item_price[i].addEventListener("keyup", generate_total_amount_bill);

            if (change_price && item_price[i].value <= 0) {
                change_price_field(item_name[i].value, i, bill_type);
            }
        }
        
    } catch (err) {
        console.error("Error adding events to elements:", err);
    }
}

/**
 * Deletes a row from the bill details table.
 */
function remove_row(btn, bill_detail_id) {
    if (parseInt(bill_detail_id) !== 0) {
        bill_detail_delete(parseInt(bill_detail_id));
    }
    btn.closest("tr").remove();
    generate_total_amount_bill();
    add_events_to_elements();
}

/**
 * Dynamically adds a new row to the bill details table.
 */
async function add_row() {
    function createElement(tag, props = {}, children = []) {
        const el = document.createElement(tag);
        Object.entries(props).forEach(([key, value]) => {
            if (key === 'className') {
                el.className = value;
            } else if (key in el) {
                el[key] = value;
            } else {
                el.setAttribute(key, value);
            }
        });
        children.forEach(child => el.appendChild(child));
        return el;
    }

    const billTypeElement = document.getElementById("bill_type");
    const tableBody = document.getElementById("table_body");
    const row = createElement("tr");
    tableBody.appendChild(row);

    // Prepare product data
    let productData = {};
    try {
        productData = JSON.parse(localStorage.getItem("product_data")) || {};
    } catch (e) {
        console.error("Invalid product_data JSON", e);
    }

    // Create search input and product <select>
    const selectId = `item_name_select_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
    const selectItemName = createElement("select", {
        id: selectId,
        className: "item_name form-control",
        name: "item_name",
        required: true
    });

    function populateOptions(filter = "") {
        selectItemName.innerHTML = ""; // clear options
        const filterLower = filter.toLowerCase();
        for (const key in productData) {
            if (Object.hasOwn(productData, key)) {
                const product = productData[key];
                const label = `${product.item_name} ${product.product_detail?.purchased_price || ""}`;
                if (label.toLowerCase().includes(filterLower)) {
                    const option = createElement("option", {
                        value: product.id,
                        innerText: label
                    });
                    selectItemName.appendChild(option);
                }
            }
        }
    }

    const itemSearchInput = createElement("input", {
        type: "text",
        placeholder: "Search item...",
        className: "form-control mb-1",
        oninput: function () {
            populateOptions(this.value);
            // ✅ After filtering, re-trigger the price change logic if something is selected
            const selectedVal = selectItemName.value;
            if (selectedVal) {
                change_price_field(selectedVal, row.rowIndex - 1, billTypeElement);
            }
        }
    });
    populateOptions(); // initial full list
    // Unit select
    const selectUnit = createElement("select", {
        className: "unit form-control",
        name: "unit",
        required: true
    });

    try {
        const unitData = JSON.parse(localStorage.getItem("unit_data")) || {};
        for (const key in unitData) {
            if (Object.hasOwn(unitData, key)) {
                const unit = unitData[key];
                const option = createElement("option", {
                    value: unit.id,
                    innerText: unit.name
                });
                selectUnit.appendChild(option);
            }
        }
    } catch (e) {
        console.error("Invalid unit_data JSON", e);
    }

    // Build the row
    row.appendChild(createElement("td", {}, [itemSearchInput, selectItemName]));
    const amountInput = createElement("input", { type: "number", className: "item_amount form-control", required: true });
    row.appendChild(createElement("td", {}, [amountInput, selectUnit]));
    const priceInput = createElement("input", { type: "number", className: "item_price form-control", min: "0", step: ".001", required: true });
    row.appendChild(createElement("td", {}, [priceInput]));
    const returnQtyInput = createElement("input", { type: "number", className: "return_qty form-control", value: 0, required: true });
    const hiddenIdInput = createElement("input", { type: "hidden", className: "bill_detail_id", required: true });
    row.appendChild(createElement("td", {}, [returnQtyInput, hiddenIdInput]));
    const removeBtn = createElement("input", {
        type: "button",
        value: "remove",
        style:"background-color:red",
        className: "remove_btn btn btn-danger",
        onclick: () => remove_row(row, 0)
    });
    row.appendChild(createElement("td", {}, [removeBtn]));

    // Event bindings
    selectItemName.addEventListener("change", e => {
        if (e.target.value) {
            change_price_field(e.target.value, row.rowIndex - 1, billTypeElement);
        }
    });

    priceInput.addEventListener("keyup", generate_total_amount_bill);
    amountInput.addEventListener("keyup", generate_total_amount_bill);
    returnQtyInput.addEventListener("input", generate_total_amount_bill);

    add_events_to_elements();
}

document.addEventListener("DOMContentLoaded", () => {
  init();
});



function getElement(id) {
  return document.getElementById(id);
}

async function init() {
  const addNawajans = getElement("addnawajans");
  addNawajans.disabled = true;
  await get_products(getElement("organization").value, false);
  await get_units();
  addNawajans.disabled = false;
}



function generate_total_amount_bill() {
  console.log("Generating total amount bill...");

  const itemAmounts = document.getElementsByClassName("item_amount");
  const itemPrices = document.getElementsByClassName("item_price");
  const returnQtys = document.getElementsByClassName("return_qty");
  const total = getElement("total");

  let offset = 0;

  for (let i = 0; i < itemAmounts.length; i++) {
      let amount = parseFloat(itemAmounts[i].value) || 0;
      let retQty = parseFloat(returnQtys[i].value) || 0;
      let price = parseFloat(itemPrices[i].value) || 0;

      if (retQty > amount) {
          returnQtys[i].value = 0;
          retQty = 0;
      }

      offset += (amount - retQty) * price;
  }

  total.value = offset.toFixed(2);
  return offset > 0;
}

function total_and_paid_validation() {
  const totalBill = parseFloat(getElement("total").value) || 0;
  const totalPayment = parseFloat(getElement("total_payment").value) || 0;
  const billType = getElement("bill_type").value;

  if (["PAYMENT", "RECEIVEMENT", "EXPENSE"].includes(billType)) {
      return true;
  }

  if (totalPayment > totalBill) {
      return false;
  }

  return true;
}

async function submit_validation_function() {
  const itemNames = [...document.getElementsByClassName("item_name")].map(input => input.value);
  const duplicateItems = itemNames.filter((v, i, a) => a.indexOf(v) !== i);

  if (duplicateItems.length > 0 && !confirm("Item is repeated. Do you want to add it again?")) {
      return false;
  }

  return generate_total_amount_bill() && total_and_paid_validation();
}

try{
  document.getElementById("bill").addEventListener("submit",async function(e){
    e.preventDefault();
    date=document.getElementById("date");
    organization=document.getElementById("organization");
    creator=document.getElementById("creator");
    total=document.getElementById("total");
    total_payment=document.getElementById("total_payment");
    bill_no=document.getElementById("bill_no");
    bill_id=document.getElementById("bill_id");
    bill_type=document.getElementById("bill_type");
    is_approved=document.getElementById("is_approved");
    // status=document.getElementById("status");
    status_bill=document.getElementById("status");
    approval_date=document.getElementById("approval_date");
    approval_user=document.getElementById("approval_user");

    item_name=document.getElementsByClassName("item_name");
    item_price=document.getElementsByClassName("item_price");
    item_amount=document.getElementsByClassName("item_amount");
    unit=document.getElementsByClassName("unit");
    return_qty=document.getElementsByClassName("return_qty");
    bill_detail_id=document.getElementsByClassName("bill_detail_id");
    
    item_name_list=[];
    item_price_list=[];
    item_amount_list=[];
    unit_list=[];
    return_qty_list=[]
    bill_detail_id_list=[]
    for(let i=0; i<item_amount.length; i++)
    {
        item_name_list.push(item_name[i].value);
        
        item_price_list.push(item_price[i].value);
        
        item_amount_list.push(item_amount[i].value);
        
        unit_list.push(unit[i].value);
        
        return_qty_list.push(return_qty[i].value);
        bill_detail_id_list.push(bill_detail_id[i].value)
    }

    bill_obj={
        
        "id":bill_id.value,
        "date":date.value,
        "organization":organization.value,
        "creator":creator.value,
        "total":total.value,
        "total_payment":total_payment.value,
        "bill_no":bill_no.value,
        "bill_type":bill_type.value,
        "is_approved":is_approved.value,
        "status":status_bill.value,
        "approval_date":approval_date.value,
        "approval_user":approval_user.value,
        
        "item_name":item_name_list,
        "item_price":item_price_list,
        "item_amount":item_amount_list,
        "unit":unit_list,
        "return_qty":return_qty_list,
        "bill_detail_id":bill_detail_id_list,
    }
    flag=await submit_validation_function();
     

     

     console.log("flage ",flag," bill_obj ",bill_obj)
     // return ;
     if(flag)
     {
         let response=await call_shirkat(
                "/bill/insert/",
                 "POST",
                 JSON.stringify(bill_obj)
             );
         console.log("response bill insert",response)
         if(response.status==200 || response.status==201){
             if(response.data.ok)
             {
                 show_message("bill Created ","success");
                 var host=location.protocol + '//' + location.host
                  window.location.href=host+"/bill/detail/"+response.data.bill_id+"/";
             }
             else
             {
                 show_message(response.data.message,"error");   
             }
         }
         else{
             show_message("bill Not Created ","error")
         }
     }   
     else{
         show_message("No Validated Form ","error")
     }
 });
}  
catch(e)
{
 console.log("getElementById(bill) error")
}



getElement("total_payment")?.addEventListener("input", total_and_paid_validation);




