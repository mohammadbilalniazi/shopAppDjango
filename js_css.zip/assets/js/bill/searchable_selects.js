/**
 * Searchable Dropdowns for Bill Forms
 * Makes organization and bill_rcvr_org selects searchable using Select2
 */

// Initialize Select2 on document ready
document.addEventListener('DOMContentLoaded', function() {
    initializeSearchableSelects();
});

/**
 * Initialize all searchable select dropdowns
 */
function initializeSearchableSelects() {
    // Check if Select2 is loaded
    if (typeof jQuery === 'undefined' || typeof jQuery.fn.select2 === 'undefined') {
        console.error('Select2 library not loaded. Please include jQuery and Select2.');
        return;
    }

    // Initialize organization dropdown
    const organizationSelect = jQuery('#organization');
    if (organizationSelect.length) {
        organizationSelect.select2({
            placeholder: 'Select Organization',
            allowClear: false,
            width: '100%',
            theme: 'default',
            language: {
                noResults: function() {
                    return 'No organization found';
                },
                searching: function() {
                    return 'Searching...';
                }
            }
        });
        console.log('✓ Organization dropdown initialized');
    }

    // Initialize bill receiver organization dropdown
    const billRcvrOrgSelect = jQuery('#bill_rcvr_org');
    if (billRcvrOrgSelect.length) {
        billRcvrOrgSelect.select2({
            placeholder: 'Select Receiver Organization',
            allowClear: false,
            width: '100%',
            theme: 'default',
            language: {
                noResults: function() {
                    return 'No organization found';
                },
                searching: function() {
                    return 'Searching...';
                }
            }
        });
        console.log('✓ Bill Receiver Organization dropdown initialized');
    }

    // Initialize existing item_name dropdowns (on page load)
    const itemNameSelects = document.querySelectorAll('.item_name');
    if (itemNameSelects.length > 0) {
        itemNameSelects.forEach(function(select) {
            if (!jQuery(select).hasClass('select2-hidden-accessible')) {
                jQuery(select).select2({
                    placeholder: 'Select or search item...',
                    allowClear: true,
                    width: '100%',
                    theme: 'default',
                    language: {
                        noResults: function() {
                            return 'No item found';
                        },
                        searching: function() {
                            return 'Searching...';
                        }
                    }
                });
            }
        });
        console.log(`✓ ${itemNameSelects.length} item_name dropdown(s) initialized`);
    }

    // Handle dynamically created bill_rcvr_org (in bill.js select_rcvr_orgs function)
    // Re-initialize after dynamic content is loaded
    observeDynamicSelects();
}

/**
 * Observe DOM changes to reinitialize Select2 on dynamically created selects
 */
function observeDynamicSelects() {
    const rcvrOrgSpan = document.getElementById('rcvr_org_span');
    const tableBody = document.getElementById('table_body');

    // Observer for bill_rcvr_org
    if (rcvrOrgSpan) {
        const rcvrObserver = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.addedNodes.length) {
                    mutation.addedNodes.forEach(function(node) {
                        if (node.nodeType === 1 && node.id === 'bill_rcvr_org') {
                            // Destroy existing select2 if present
                            if (jQuery(node).hasClass('select2-hidden-accessible')) {
                                jQuery(node).select2('destroy');
                            }
                            
                            // Initialize Select2 on the new element
                            jQuery(node).select2({
                                placeholder: 'Select Receiver Organization',
                                allowClear: false,
                                width: '100%',
                                theme: 'default'
                            });
                            console.log('✓ Dynamically created bill_rcvr_org initialized');
                        }
                    });
                }
            });
        });

        // Start observing rcvr_org_span
        rcvrObserver.observe(rcvrOrgSpan, { childList: true, subtree: true });
    }

    // Observer for dynamically added item_name selects in table rows
    if (tableBody) {
        const tableObserver = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.addedNodes.length) {
                    mutation.addedNodes.forEach(function(node) {
                        // Check if a new row (TR) was added
                        if (node.nodeType === 1 && node.tagName === 'TR') {
                            // Find all .item_name selects in the new row
                            const itemSelects = node.querySelectorAll('.item_name');
                            itemSelects.forEach(function(select) {
                                // Skip if already initialized
                                if (!jQuery(select).hasClass('select2-hidden-accessible')) {
                                    // Small delay to ensure DOM is ready
                                    setTimeout(function() {
                                        jQuery(select).select2({
                                            placeholder: 'Select or search item...',
                                            allowClear: true,
                                            width: '100%',
                                            theme: 'default',
                                            language: {
                                                noResults: function() {
                                                    return 'No item found';
                                                },
                                                searching: function() {
                                                    return 'Searching...';
                                                }
                                            }
                                        });
                                        console.log('✓ Dynamically created item_name select initialized');
                                    }, 50);
                                }
                            });
                        }
                    });
                }
            });
        });

        // Start observing table_body
        tableObserver.observe(tableBody, { childList: true });
    }
}

/**
 * Reinitialize a specific select element
 * @param {string} selectId - The ID of the select element
 */
function reinitializeSelect(selectId) {
    const selectElement = jQuery('#' + selectId);
    if (selectElement.length) {
        // Destroy if already initialized
        if (selectElement.hasClass('select2-hidden-accessible')) {
            selectElement.select2('destroy');
        }
        
        // Reinitialize
        selectElement.select2({
            placeholder: 'Select ' + selectId.replace('_', ' '),
            allowClear: false,
            width: '100%',
            theme: 'default'
        });
        console.log('✓ ' + selectId + ' reinitialized');
    }
}

/**
 * Get selected value from Select2 dropdown
 * @param {string} selectId - The ID of the select element
 * @returns {string|null} Selected value
 */
function getSelectValue(selectId) {
    const selectElement = jQuery('#' + selectId);
    return selectElement.length ? selectElement.val() : null;
}

/**
 * Set value for Select2 dropdown
 * @param {string} selectId - The ID of the select element
 * @param {string} value - Value to set
 */
function setSelectValue(selectId, value) {
    const selectElement = jQuery('#' + selectId);
    if (selectElement.length) {
        selectElement.val(value).trigger('change');
    }
}

/**
 * Disable/Enable Select2 dropdown
 * @param {string} selectId - The ID of the select element
 * @param {boolean} disabled - True to disable, false to enable
 */
function toggleSelectDisabled(selectId, disabled) {
    const selectElement = jQuery('#' + selectId);
    if (selectElement.length) {
        selectElement.prop('disabled', disabled);
    }
}

// Export functions for use in other scripts
window.initializeSearchableSelects = initializeSearchableSelects;
window.reinitializeSelect = reinitializeSelect;
window.getSelectValue = getSelectValue;
window.setSelectValue = setSelectValue;
window.toggleSelectDisabled = toggleSelectDisabled;

console.log('✓ Searchable selects module loaded');
