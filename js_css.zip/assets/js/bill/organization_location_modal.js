/**
 * Organization and Location Modal Management
 * Handles popup forms for adding organizations and locations from bill forms
 */

// ==================== ORGANIZATION MODAL ====================

function openOrganizationModal() {
    const modal = document.getElementById('organizationModal');
    modal.style.display = 'block';
    
    // Load locations for the dropdown
    loadLocationsForOrgModal();
}

function closeOrganizationModal() {
    const modal = document.getElementById('organizationModal');
    modal.style.display = 'none';
    
    // Reset form
    document.getElementById('modal_organization_form').reset();
}

async function loadLocationsForOrgModal() {
    try {
        const response = await fetch('/configuration/location/all/');
        const data = await response.json();
        
        const locationSelect = document.getElementById('modal_org_location');
        locationSelect.innerHTML = '<option value="">Select Location</option>';
        
        data.forEach(location => {
            const option = document.createElement('option');
            option.value = location.id;
            // Location doesn't have a 'name' field, construct display text from available fields
            // Format: "Country_State" or "State, City" depending on what's available
            const displayText = location.state && location.city 
                ? `${location.state}, ${location.city}` 
                : (location.state || location.city || `Location ${location.id}`);
            option.textContent = displayText;
            locationSelect.appendChild(option);
        });
        
        console.log('✓ Locations loaded for organization modal');
    } catch (error) {
        console.error('Error loading locations:', error);
        show_message('Failed to load locations', 'error');
    }
}

// Handle organization form submission
document.addEventListener('DOMContentLoaded', function() {
    const orgForm = document.getElementById('modal_organization_form');
    if (orgForm) {
        orgForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = {
                owner: formData.get('owner'),
                type: formData.get('type'),
                name: formData.get('name'),
                email: formData.get('email'),
                password: formData.get('password'),
                location: formData.get('location'),
                is_active: formData.get('is_active') ? true : false,
                created_date: new Date().toISOString().split('T')[0]
            };
            
            try {
                const response = await call_shirkat(
                    '/configuration/organization/form/create/',
                    'POST',
                    JSON.stringify(data)
                );
                
                if (response.status === 200 || response.status === 201) {
                    show_message('Organization created successfully!', 'success');
                    closeOrganizationModal();
                    
                    // Refresh the bill_rcvr_org dropdown
                    await refreshBillRcvrOrgDropdown();
                } else {
                    show_message('Failed to create organization', 'error');
                }
            } catch (error) {
                console.error('Error creating organization:', error);
                show_message('Error: ' + error.message, 'error');
            }
        });
    }
    
    // Close modal when clicking the X
    const orgCloseBtn = document.querySelector('.organization-modal-close');
    if (orgCloseBtn) {
        orgCloseBtn.onclick = closeOrganizationModal;
    }
    
    // Close modal when clicking outside of it
    window.addEventListener('click', function(event) {
        const orgModal = document.getElementById('organizationModal');
        if (event.target === orgModal) {
            closeOrganizationModal();
        }
    });
});

async function refreshBillRcvrOrgDropdown() {
    try {
        const response = await fetch('/organizations/all/');
        const data = await response.json();
        
        const billRcvrOrgSelect = document.getElementById('bill_rcvr_org');
        if (!billRcvrOrgSelect) return;
        
        // Store current value
        const currentValue = billRcvrOrgSelect.value;
        
        // Rebuild options
        billRcvrOrgSelect.innerHTML = '';
        
        data.forEach(org => {
            const option = document.createElement('option');
            option.value = org.id;
            option.textContent = org.name;
            billRcvrOrgSelect.appendChild(option);
        });
        
        // Select the last added organization (newest)
        if (data.length > 0) {
            billRcvrOrgSelect.value = data[0].id;
        }
        
        // Reinitialize Select2 if it exists
        if (typeof jQuery !== 'undefined' && typeof jQuery.fn.select2 !== 'undefined') {
            jQuery('#bill_rcvr_org').select2('destroy');
            jQuery('#bill_rcvr_org').select2({
                placeholder: 'Select Receiver Organization',
                allowClear: false,
                width: '100%',
                theme: 'default'
            });
        }
        
        console.log('✓ Bill receiver organization dropdown refreshed');
    } catch (error) {
        console.error('Error refreshing bill_rcvr_org dropdown:', error);
    }
}

// ==================== LOCATION MODAL ====================

function openLocationModal() {
    const modal = document.getElementById('locationModal');
    modal.style.display = 'block';
    
    // Load countries for the dropdown
    loadCountriesForLocationModal();
}

function closeLocationModal() {
    const modal = document.getElementById('locationModal');
    modal.style.display = 'none';
    
    // Reset form
    document.getElementById('modal_location_form').reset();
}

// ==================== COUNTRY MODAL ====================

function openCountryModal() {
    const modal = document.getElementById('countryModal');
    modal.style.display = 'block';
}

function closeCountryModal() {
    const modal = document.getElementById('countryModal');
    modal.style.display = 'none';
    
    // Reset form
    document.getElementById('modal_country_form').reset();
}

async function loadCountriesForLocationModal() {
    try {
        const response = await fetch('/configuration/countries/');
        const data = await response.json();
        
        const countrySelect = document.getElementById('modal_location_country');
        countrySelect.innerHTML = '<option value="">Select Country</option>';
        
        data.forEach(country => {
            const option = document.createElement('option');
            option.value = country.id;
            option.textContent = country.name;
            countrySelect.appendChild(option);
        });
        
        console.log('✓ Countries loaded for location modal');
    } catch (error) {
        console.error('Error loading countries:', error);
        show_message('Failed to load countries', 'error');
    }
}

// Handle location form submission
document.addEventListener('DOMContentLoaded', function() {
    const locationForm = document.getElementById('modal_location_form');
    if (locationForm) {
        locationForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = {
                country: formData.get('country'),
                state: formData.get('state'),
                city: formData.get('city'),
                is_active: true
            };
            
            try {
                const response = await call_shirkat(
                    '/configuration/location/all/',
                    'POST',
                    JSON.stringify(data)
                );
                
                if (response.status === 200 || response.status === 201) {
                    show_message('Location created successfully!', 'success');
                    closeLocationModal();
                    
                    // Refresh the location dropdown in organization modal
                    await loadLocationsForOrgModal();
                    
                    // Select the newly created location
                    if (response.data && response.data.data && response.data.data.id) {
                        const locationSelect = document.getElementById('modal_org_location');
                        if (locationSelect) {
                            locationSelect.value = response.data.data.id;
                        }
                    }
                } else {
                    const errorMsg = response.data && response.data.error ? response.data.error : 'Failed to create location';
                    show_message(errorMsg, 'error');
                }
            } catch (error) {
                console.error('Error creating location:', error);
                show_message('Error: ' + error.message, 'error');
            }
        });
    }
    
    // Handle country form submission
    const countryForm = document.getElementById('modal_country_form');
    if (countryForm) {
        countryForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const data = {
                name: formData.get('name'),
                shortcut: formData.get('shortcut'),
                currency: formData.get('currency') || 'Afg'
            };
            
            try {
                const response = await call_shirkat(
                    '/configuration/countries/',
                    'POST',
                    JSON.stringify(data)
                );
                
                if (response.status === 200 || response.status === 201) {
                    show_message('Country created successfully!', 'success');
                    closeCountryModal();
                    
                    // Refresh the country dropdown in location modal
                    await loadCountriesForLocationModal();
                    
                    // Select the newly created country
                    if (response.data && response.data.data && response.data.data.id) {
                        const countrySelect = document.getElementById('modal_location_country');
                        if (countrySelect) {
                            countrySelect.value = response.data.data.id;
                        }
                    }
                } else {
                    const errorMsg = response.data && response.data.error ? response.data.error : 'Failed to create country';
                    show_message(errorMsg, 'error');
                }
            } catch (error) {
                console.error('Error creating country:', error);
                show_message('Error: ' + error.message, 'error');
            }
        });
    }
    
    // Close modal when clicking the X
    const locationCloseBtn = document.querySelector('.location-modal-close');
    if (locationCloseBtn) {
        locationCloseBtn.onclick = closeLocationModal;
    }
    
    const countryCloseBtn = document.querySelector('.country-modal-close');
    if (countryCloseBtn) {
        countryCloseBtn.onclick = closeCountryModal;
    }
    
    // Close modal when clicking outside of it
    window.addEventListener('click', function(event) {
        const locationModal = document.getElementById('locationModal');
        if (event.target === locationModal) {
            closeLocationModal();
        }
        
        const countryModal = document.getElementById('countryModal');
        if (event.target === countryModal) {
            closeCountryModal();
        }
    });
});

console.log('✅ Organization and Location modal scripts loaded');
