/**
 * MIGRATION EXAMPLES - Converting Old Code to New API Manager
 * 
 * This file shows how to convert existing API calls to use the new
 * centralized API Manager with unified toast message handling
 */

// ============================================================================
// EXAMPLE 1: Basic API Call Migration
// ============================================================================

// ❌ OLD WAY (Before API Manager)
async function oldWayAPICall() {
    try {
        let response = await call_shirkat("/products/", "POST", JSON.stringify(data));
        
        if (response.status === 200 || response.status === 201) {
            alert("Success!"); // Poor UX
            // Manual DOM manipulation
            updateProductList(response.data);
        } else {
            alert("Error: " + response.data.message); // Poor UX
        }
    } catch (error) {
        alert("Network error!"); // Poor UX
    }
}

// ✅ NEW WAY (With API Manager) - ONE FOCAL POINT
async function newWayAPICall() {
    const result = await apiManager.post('/products/', data, {
        showLoading: true,
        messages: {
            success: 'Products loaded successfully!',
            error: 'Failed to load products'
        }
    });
    
    if (result.success) {
        updateProductList(result.data); // Beautiful toast already shown!
    }
    // Error handling automatic with beautiful toast!
}

// ============================================================================
// EXAMPLE 2: Stock Update Migration
// ============================================================================

// ❌ OLD WAY
async function oldStockUpdate(product_id) {
    const input = document.getElementById(`stock_input_${product_id}`);
    const current_amount = input.value;
    const organization_id = document.getElementById("organization").value;

    if (!organization_id) {
        alert("لطفاً اداره انتخاب کړئ"); // Poor UX
        return false;
    }

    const formData = {
        current_amount: current_amount,
        product_id: product_id,
        organization_id: organization_id
    };

    let response = await call_shirkat("/stock/update/", "POST", JSON.stringify(formData));
    let message = document.getElementById("update_stock_message");

    if (response.status === 201 || response.status === 200) {
        message.innerHTML = "ذخیره معلومات نوي شول"; // Manual DOM
        message.style.display = 'block';
        setTimeout(() => {
            message.innerHTML = "";
            message.style.display = 'none';
        }, 2000);
    } else {
        alert("خطا: " + JSON.stringify(response.data)); // Poor UX
    }
}

// ✅ NEW WAY - UNIFIED RESPONSE HANDLING
async function newStockUpdate(product_id) {
    const input = document.getElementById(`stock_input_${product_id}`);
    const current_amount = input.value;
    const organizationSelect = document.getElementById("organization");
    
    if (!organizationSelect || !organizationSelect.value) {
        apiManager.showToast("Please select an organization first", 'warning');
        return false;
    }
    
    const formData = {
        current_amount: parseInt(current_amount),
        product_id: product_id,
        organization_id: organizationSelect.value
    };
    
    // Single focal point with unified response handling
    const response = await apiManager.post('/stock/update/', formData, {
        showLoading: true,
        messages: {
            success: `Stock updated successfully for product ${product_id}`,
            error: 'Failed to update stock. Please try again.'
        }
    });
    
    if (response.success) {
        // Visual feedback - no manual DOM manipulation needed
        input.style.backgroundColor = 'var(--color-success-lighter)';
        setTimeout(() => input.style.backgroundColor = '', 1500);
    }
    // Error handling is automatic with beautiful toasts!
}

// ============================================================================
// EXAMPLE 3: Form Submission Migration
// ============================================================================

// ❌ OLD WAY - Manual form handling
function oldFormSubmission() {
    const form = document.getElementById('user-form');
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Manual form data collection
        const formData = new FormData(form);
        const jsonData = {};
        for (let [key, value] of formData.entries()) {
            jsonData[key] = value;
        }
        
        try {
            let response = await call_shirkat(form.action, "POST", JSON.stringify(jsonData));
            
            if (response.status === 200) {
                alert("Form submitted successfully!"); // Poor UX
                form.reset();
                window.location.href = '/success-page/';
            } else {
                alert("Failed to submit form: " + response.data.message); // Poor UX
            }
        } catch (error) {
            alert("Network error occurred!"); // Poor UX
        }
    });
}

// ✅ NEW WAY - Simplified with API Manager
function newFormSubmission() {
    const form = document.getElementById('user-form');
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Single line form submission with unified handling!
        const result = await apiManager.submitForm(form, {
            showLoading: true,
            messages: {
                success: 'Form submitted successfully!',
                error: 'Failed to submit form'
            }
        });
        
        if (result.success) {
            form.reset();
            window.location.href = '/success-page/';
        }
        // Error handling is automatic!
    });
}

// ============================================================================
// EXAMPLE 4: File Upload Migration
// ============================================================================

// ❌ OLD WAY - Complex file upload handling
function oldFileUpload() {
    const fileInput = document.getElementById('file-input');
    fileInput.addEventListener('change', async (e) => {
        const files = e.target.files;
        if (files.length === 0) return;
        
        const formData = new FormData();
        formData.append('file', files[0]);
        
        try {
            // Manual fetch with CSRF token handling
            const csrfToken = document.querySelector('[name=csrfmiddlewaretoken]').value;
            
            let response = await fetch('/upload/', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRFToken': csrfToken
                }
            });
            
            if (response.ok) {
                const data = await response.json();
                alert("File uploaded successfully!"); // Poor UX
                updateImagePreview(data.file_url);
            } else {
                alert("File upload failed!"); // Poor UX
            }
        } catch (error) {
            alert("Upload error occurred!"); // Poor UX
        }
    });
}

// ✅ NEW WAY - Simple and elegant
function newFileUpload() {
    const fileInput = document.getElementById('file-input');
    fileInput.addEventListener('change', async (e) => {
        // One line file upload with automatic CSRF and error handling!
        const result = await apiManager.uploadFile(
            '/upload/',
            e.target,
            { description: 'Product image' },
            {
                messages: {
                    success: 'File uploaded successfully!',
                    error: 'Failed to upload file'
                }
            }
        );
        
        if (result.success) {
            updateImagePreview(result.data.file_url);
        }
        // Error handling is automatic with beautiful toasts!
    });
}

// ============================================================================
// EXAMPLE 5: Search Functionality Migration
// ============================================================================

// ❌ OLD WAY - Manual search with alerts
async function oldSearchFunction(query) {
    try {
        const response = await call_shirkat('/search/', 'POST', JSON.stringify({ query }));
        
        if (response.status === 200) {
            if (response.data.results.length === 0) {
                alert("No results found"); // Poor UX
            } else {
                displayResults(response.data.results);
            }
        } else {
            alert("Search failed: " + response.data.message); // Poor UX
        }
    } catch (error) {
        alert("Search error!"); // Poor UX
    }
}

// ✅ NEW WAY - Elegant with toast notifications
async function newSearchFunction(query) {
    const result = await apiManager.post('/search/', { query }, {
        messages: {
            error: 'Search failed. Please try again.'
        }
    });
    
    if (result.success) {
        if (result.data.results.length === 0) {
            apiManager.showToast("No results found for your search", 'info');
        } else {
            displayResults(result.data.results);
            apiManager.showToast(`Found ${result.data.results.length} results`, 'success');
        }
    }
    // Error handling is automatic!
}

// ============================================================================
// EXAMPLE 6: Batch Operations Migration
// ============================================================================

// ❌ OLD WAY - Sequential API calls with manual error tracking
async function oldBatchDelete(itemIds) {
    let successCount = 0;
    let failCount = 0;
    
    for (const id of itemIds) {
        try {
            const response = await call_shirkat(`/delete/${id}/`, 'DELETE');
            if (response.status === 200) {
                successCount++;
            } else {
                failCount++;
            }
        } catch (error) {
            failCount++;
        }
    }
    
    alert(`Deleted ${successCount} items, ${failCount} failed`); // Poor UX
}

// ✅ NEW WAY - Efficient batch processing
async function newBatchDelete(itemIds) {
    const deleteRequests = itemIds.map(id => ({
        url: `/delete/${id}/`,
        options: { method: 'DELETE' }
    }));
    
    // Single focal point handles all requests efficiently!
    const results = await apiManager.batch(deleteRequests);
    
    // Automatic success/failure counting with beautiful toast!
}

// ============================================================================
// MIGRATION BENEFITS SUMMARY
// ============================================================================

/*
✅ BENEFITS OF NEW API MANAGER:

1. 🎯 SINGLE FOCAL POINT
   - All API calls go through one centralized manager
   - Consistent patterns across entire application
   - Easy to maintain and debug

2. 🎨 BEAUTIFUL UI/UX
   - Replace ugly alerts with beautiful toast notifications
   - Consistent success/error/warning/info messages
   - Mobile-responsive design with animations

3. 🔒 AUTOMATIC SECURITY
   - CSRF token handling built-in
   - No need to manually manage security tokens

4. ⚡ SIMPLIFIED CODE
   - Reduce 20+ lines of code to 5-10 lines
   - No more manual error handling boilerplate
   - Automatic loading states and retry mechanisms

5. 🛠️ UNIFIED RESPONSE HANDLING
   - Consistent success/error response format
   - Automatic toast message display
   - Built-in error categorization and handling

6. 📱 BETTER USER EXPERIENCE
   - Loading indicators for slow operations
   - Visual feedback for all user actions
   - Professional toast notifications instead of alerts

7. 🔧 EASIER MAINTENANCE
   - Centralized API configuration
   - Easy to update endpoints across entire app
   - Consistent error handling patterns

8. 🚀 DEVELOPER PRODUCTIVITY
   - Less code to write and maintain
   - Built-in best practices
   - Comprehensive documentation and examples

MIGRATION STRATEGY:
1. Include API Manager scripts in master.html ✅
2. Replace old call_shirkat() calls with apiManager methods
3. Remove manual alert() calls - toast messages are automatic
4. Use predefined API_ENDPOINTS for consistency
5. Leverage built-in form and file upload helpers
6. Test with beautiful toast notifications

RESULT: Professional, maintainable, user-friendly API layer! 🎉
*/

console.log('📚 API Manager Migration Examples loaded successfully');
console.log('💡 Convert your existing API calls to use the new unified system!');