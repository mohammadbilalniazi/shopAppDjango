/**
 * API Usage Examples for Django Shop Application
 * Demonstrates how to use the centralized APIManager for common operations
 */

// ============================================================================
// BASIC API CALLS EXAMPLES
// ============================================================================

async function exampleBasicAPICalls() {
    console.log('=== Basic API Calls Examples ===');
    
    // Simple GET request
    const users = await apiManager.get('/user/organization_user/get/', {
        messages: {
            success: 'Users loaded successfully',
            error: 'Failed to load users'
        }
    });
    
    if (users.success) {
        console.log('Users data:', users.data);
    }

    // POST request with data
    const newUser = await apiManager.post('/user/organization_user/insert/', {
        username: 'newuser',
        email: 'user@example.com',
        organization: 1
    }, {
        showLoading: true,
        messages: {
            success: 'User created successfully!',
            error: 'Failed to create user'
        }
    });

    // PUT request for updates
    const updateResult = await apiManager.put(API_HELPERS.updateUser(123), {
        first_name: 'Updated Name'
    });

    // DELETE request
    const deleteResult = await apiManager.delete(API_HELPERS.deleteUser(123), {
        messages: {
            success: 'User deleted successfully',
            error: 'Failed to delete user'
        }
    });
}

// ============================================================================
// FORM SUBMISSION EXAMPLES
// ============================================================================

// Example 1: User form submission
async function handleUserFormSubmission() {
    const form = document.getElementById('user-form');
    
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const result = await apiManager.submitForm(form, {
            messages: {
                success: 'User information saved successfully!',
                error: 'Failed to save user information'
            },
            showLoading: true
        });
        
        if (result.success) {
            // Redirect or update UI
            window.location.href = '/user/organization_user/get/';
        }
    });
}

// Example 2: Product form with file upload
async function handleProductFormWithImage() {
    const productForm = document.getElementById('product-form');
    
    productForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = new FormData(productForm);
        
        const result = await apiManager.post('/admin/product/product/add/', formData, {
            headers: {
                // Don't set Content-Type for FormData, let browser set it
            },
            messages: {
                success: 'Product created successfully!',
                error: 'Failed to create product'
            },
            showLoading: true
        });
        
        if (result.success) {
            productForm.reset();
            // Refresh product list or redirect
            loadProducts();
        }
    });
}

// ============================================================================
// SEARCH AND FILTERING EXAMPLES
// ============================================================================

// Example: Live search functionality
function setupLiveSearch() {
    const searchInput = document.getElementById('search-input');
    const resultsContainer = document.getElementById('search-results');
    let searchTimeout;
    
    searchInput.addEventListener('input', async (e) => {
        const query = e.target.value.trim();
        
        // Clear previous timeout
        clearTimeout(searchTimeout);
        
        if (query.length < 2) {
            resultsContainer.innerHTML = '';
            return;
        }
        
        // Debounce search
        searchTimeout = setTimeout(async () => {
            const results = await apiManager.post('/user/organization_user/search/', {
                query: query
            }, {
                messages: {
                    error: 'Search failed. Please try again.'
                }
            });
            
            if (results.success) {
                displaySearchResults(results.data);
            }
        }, 300);
    });
}

// ============================================================================
// BRANCH MANAGEMENT EXAMPLES
// ============================================================================

async function branchManagementExamples() {
    console.log('=== Branch Management Examples ===');
    
    // Load branches for an organization
    async function loadBranchesForOrganization(orgId) {
        const branches = await apiManager.get(API_HELPERS.branchesByOrganization(orgId), {
            messages: {
                success: 'Branches loaded successfully',
                error: 'Failed to load branches'
            }
        });
        
        return branches;
    }
    
    // Create new branch
    async function createBranch(branchData) {
        const result = await apiManager.post(API_ENDPOINTS.BRANCH.CREATE, branchData, {
            showLoading: true,
            messages: {
                success: 'Branch created successfully!',
                error: 'Failed to create branch'
            }
        });
        
        if (result.success) {
            // Refresh branch list
            loadBranchesForOrganization(branchData.organization_id);
        }
        
        return result;
    }
    
    // Toggle branch status
    async function toggleBranchStatus(branchId) {
        const result = await apiManager.post(API_HELPERS.branchToggleStatus(branchId), {}, {
            messages: {
                success: 'Branch status updated successfully',
                error: 'Failed to update branch status'
            }
        });
        
        return result;
    }
    
    // Delete branch with confirmation
    async function deleteBranch(branchId, branchName) {
        if (!confirm(`Are you sure you want to delete branch "${branchName}"?`)) {
            return;
        }
        
        const result = await apiManager.delete(API_HELPERS.branchDelete(branchId), {
            messages: {
                success: 'Branch deleted successfully',
                error: 'Failed to delete branch'
            }
        });
        
        return result;
    }
}

// ============================================================================
// BILL MANAGEMENT EXAMPLES
// ============================================================================

async function billManagementExamples() {
    console.log('=== Bill Management Examples ===');
    
    // Create new bill
    async function createBill(billData) {
        const result = await apiManager.post(API_ENDPOINTS.BILL.INSERT, billData, {
            showLoading: true,
            messages: {
                success: 'Bill created successfully!',
                error: 'Failed to create bill'
            }
        });
        
        return result;
    }
    
    // Search bills
    async function searchBills(searchCriteria) {
        const results = await apiManager.post(API_ENDPOINTS.BILL.SEARCH, searchCriteria, {
            messages: {
                error: 'Failed to search bills'
            }
        });
        
        return results;
    }
    
    // Finalize ledger
    async function finalizeLedger(organizationId) {
        const result = await apiManager.post(API_ENDPOINTS.BILL.FINALIZE_LEDGER, {
            organization_id: organizationId
        }, {
            showLoading: true,
            messages: {
                success: 'Ledger finalized successfully!',
                error: 'Failed to finalize ledger'
            }
        });
        
        return result;
    }
}

// ============================================================================
// FILE UPLOAD EXAMPLES
// ============================================================================

function setupFileUploadExamples() {
    // Product image upload
    const productImageInput = document.getElementById('product-image');
    
    if (productImageInput) {
        productImageInput.addEventListener('change', async (e) => {
            const result = await apiManager.uploadFile(
                '/admin/product/product/add/',
                e.target,
                {
                    product_id: document.getElementById('product-id').value,
                    upload_type: 'product_image'
                },
                {
                    messages: {
                        success: 'Product image uploaded successfully!',
                        error: 'Failed to upload product image'
                    }
                }
            );
            
            if (result.success) {
                // Update image preview
                updateImagePreview(result.data.image_url);
            }
        });
    }
}

// ============================================================================
// BATCH OPERATIONS EXAMPLES
// ============================================================================

async function batchOperationsExamples() {
    console.log('=== Batch Operations Examples ===');
    
    // Delete multiple users
    async function deleteMultipleUsers(userIds) {
        const deleteRequests = userIds.map(id => ({
            url: API_HELPERS.deleteUser(id),
            options: {
                method: 'DELETE',
                messages: {
                    error: `Failed to delete user ${id}`
                }
            }
        }));
        
        const results = await apiManager.batch(deleteRequests);
        return results;
    }
    
    // Update multiple products
    async function updateMultipleProducts(updates) {
        const updateRequests = updates.map(update => ({
            url: API_HELPERS.productUpdate(update.id),
            options: {
                method: 'PUT',
                body: update.data
            }
        }));
        
        const results = await apiManager.batch(updateRequests);
        return results;
    }
}

// ============================================================================
// ERROR HANDLING EXAMPLES
// ============================================================================

async function errorHandlingExamples() {
    console.log('=== Error Handling Examples ===');
    
    // Retry failed requests
    async function reliableAPICall(url, options) {
        const result = await apiManager.requestWithRetry(url, options, 3);
        
        if (!result.success) {
            console.error('API call failed after retries:', result.error);
            // Handle persistent failure
        }
        
        return result;
    }
    
    // Custom error handling
    async function customErrorHandling() {
        const result = await apiManager.get('/some/api/endpoint');
        
        if (!result.success) {
            // Custom error handling based on error type
            if (result.error.includes('permission')) {
                apiManager.showToast('You do not have permission to perform this action', 'warning');
                // Redirect to login or show permission error
            } else if (result.error.includes('network')) {
                apiManager.showToast('Network error. Please check your connection.', 'error');
            } else {
                // Generic error handling
                console.error('API Error:', result.error);
            }
        }
    }
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

function displaySearchResults(results) {
    const container = document.getElementById('search-results');
    if (!results || results.length === 0) {
        container.innerHTML = '<p>No results found</p>';
        return;
    }
    
    const html = results.map(item => `
        <div class="search-result-item">
            <h5>${item.name}</h5>
            <p>${item.description}</p>
        </div>
    `).join('');
    
    container.innerHTML = html;
}

function updateImagePreview(imageUrl) {
    const preview = document.getElementById('image-preview');
    if (preview) {
        preview.src = imageUrl;
        preview.style.display = 'block';
    }
}

async function loadProducts() {
    const products = await apiManager.get(API_ENDPOINTS.PRODUCT.LIST);
    if (products.success) {
        // Update product list UI
        updateProductList(products.data);
    }
}

function updateProductList(products) {
    // Implementation to update product list in UI
    console.log('Updating product list with:', products);
}

// ============================================================================
// INITIALIZATION
// ============================================================================

document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 API Examples loaded. apiManager available globally.');
    console.log('📋 Available examples:');
    console.log('  - exampleBasicAPICalls()');
    console.log('  - handleUserFormSubmission()');
    console.log('  - branchManagementExamples()');
    console.log('  - billManagementExamples()');
    console.log('  - batchOperationsExamples()');
    console.log('  - errorHandlingExamples()');
    
    // Initialize form handlers
    setupLiveSearch();
    setupFileUploadExamples();
    handleUserFormSubmission();
    handleProductFormWithImage();
});

// Export functions for global use
if (typeof window !== 'undefined') {
    window.apiExamples = {
        exampleBasicAPICalls,
        handleUserFormSubmission,
        handleProductFormWithImage,
        setupLiveSearch,
        branchManagementExamples,
        billManagementExamples,
        batchOperationsExamples,
        errorHandlingExamples
    };
}