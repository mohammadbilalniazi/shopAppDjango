/**
 * Centralized API Manager for Django Shop Application
 * Handles all API calls from one focal point with unified response handling
 * Manages success/error toast messages consistently across the application
 */

class APIManager {
    constructor() {
        this.baseURL = '';
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        };
        this.isInitialized = false;
        this.init();
    }

    /**
     * Initialize API Manager
     */
    init() {
        // Get CSRF token from Django
        this.csrfToken = this.getCSRFToken();
        if (this.csrfToken) {
            this.defaultHeaders['X-CSRFToken'] = this.csrfToken;
        }

        // Initialize toast notification system
        this.initializeToastSystem();
        this.isInitialized = true;
        console.log('✅ API Manager initialized successfully');
    }

    /**
     * Get CSRF token from Django
     */
    getCSRFToken() {
        const name = 'csrftoken';
        let cookieValue = null;
        if (document.cookie && document.cookie !== '') {
            const cookies = document.cookie.split(';');
            for (let i = 0; i < cookies.length; i++) {
                const cookie = cookies[i].trim();
                if (cookie.substring(0, name.length + 1) === (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        
        // Also try meta tag
        if (!cookieValue) {
            const metaTag = document.querySelector('[name=csrfmiddlewaretoken]');
            if (metaTag) {
                cookieValue = metaTag.getAttribute('value');
            }
        }
        
        return cookieValue;
    }

    /**
     * Initialize Toast Notification System
     */
    initializeToastSystem() {
        // Create toast container if it doesn't exist
        if (!document.getElementById('toast-container')) {
            const toastContainer = document.createElement('div');
            toastContainer.id = 'toast-container';
            toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
            toastContainer.style.zIndex = '9999';
            document.body.appendChild(toastContainer);
        }

        // Add toast CSS if not already present
        if (!document.getElementById('toast-styles')) {
            const toastStyles = document.createElement('style');
            toastStyles.id = 'toast-styles';
            toastStyles.innerHTML = `
                .toast-container {
                    z-index: 9999 !important;
                }
                
                .api-toast {
                    min-width: 300px;
                    max-width: 500px;
                    border: none;
                    border-radius: var(--radius-md, 8px);
                    box-shadow: var(--shadow-lg, 0 10px 25px rgba(0, 0, 0, 0.1));
                    backdrop-filter: blur(10px);
                }
                
                .api-toast.success {
                    background: linear-gradient(135deg, var(--color-success, #10b981) 0%, var(--color-success-light, #34d399) 100%);
                    color: white;
                }
                
                .api-toast.error {
                    background: linear-gradient(135deg, var(--color-danger, #ef4444) 0%, var(--color-danger-light, #f87171) 100%);
                    color: white;
                }
                
                .api-toast.warning {
                    background: linear-gradient(135deg, var(--color-warning, #f59e0b) 0%, var(--color-warning-light, #fbbf24) 100%);
                    color: white;
                }
                
                .api-toast.info {
                    background: linear-gradient(135deg, var(--color-info, #3b82f6) 0%, var(--color-info-light, #60a5fa) 100%);
                    color: white;
                }
                
                .api-toast .toast-header {
                    background: transparent;
                    border-bottom: 1px solid rgba(255, 255, 255, 0.2);
                    color: inherit;
                }
                
                .api-toast .toast-body {
                    font-weight: 500;
                }
                
                .api-toast .btn-close {
                    filter: brightness(0) invert(1);
                }
                
                .api-toast .toast-icon {
                    font-size: 1.2em;
                    margin-right: 0.5rem;
                }
                
                @keyframes slideInRight {
                    from {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
                
                .api-toast {
                    animation: slideInRight 0.3s ease-out;
                }
            `;
            document.head.appendChild(toastStyles);
        }
    }

    /**
     * Show toast notification
     */
    showToast(message, type = 'info', title = null, duration = 5000) {
        const toastContainer = document.getElementById('toast-container');
        const toastId = 'toast-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
        
        const icons = {
            success: '✅',
            error: '❌',
            warning: '⚠️',
            info: 'ℹ️'
        };

        const titles = {
            success: title || 'Success',
            error: title || 'Error',
            warning: title || 'Warning',
            info: title || 'Information'
        };

        const toastHTML = `
            <div id="${toastId}" class="toast api-toast ${type}" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="true" data-bs-delay="${duration}">
                <div class="toast-header">
                    <span class="toast-icon">${icons[type]}</span>
                    <strong class="me-auto">${titles[type]}</strong>
                    <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
                <div class="toast-body">
                    ${message}
                </div>
            </div>
        `;

        toastContainer.insertAdjacentHTML('beforeend', toastHTML);
        
        // Initialize and show toast
        const toastElement = document.getElementById(toastId);
        if (window.bootstrap && bootstrap.Toast) {
            const toast = new bootstrap.Toast(toastElement);
            toast.show();
            
            // Remove toast element after it's hidden
            toastElement.addEventListener('hidden.bs.toast', () => {
                toastElement.remove();
            });
        } else {
            // Fallback if Bootstrap is not available
            setTimeout(() => {
                toastElement.style.display = 'block';
                setTimeout(() => {
                    toastElement.remove();
                }, duration);
            }, 100);
        }
    }

    /**
     * Handle API Response and show appropriate toast
     */
    handleResponse(response, data, customMessages = {}) {
        if (response.ok) {
            const message = customMessages.success || data?.message || 'Operation completed successfully';
            this.showToast(message, 'success');
            return { success: true, data: data };
        } else {
            let errorMessage = customMessages.error || 'An error occurred';
            
            if (data?.message) {
                errorMessage = data.message;
            } else if (data?.error) {
                errorMessage = data.error;
            } else if (data?.errors) {
                if (Array.isArray(data.errors)) {
                    errorMessage = data.errors.join(', ');
                } else if (typeof data.errors === 'object') {
                    errorMessage = Object.values(data.errors).flat().join(', ');
                }
            }
            
            this.showToast(errorMessage, 'error');
            return { success: false, error: errorMessage, data: data };
        }
    }

    /**
     * Generic API request method
     */
    async request(url, options = {}) {
        if (!this.isInitialized) {
            console.warn('API Manager not initialized. Initializing now...');
            this.init();
        }

        try {
            // Prepare request options
            const requestOptions = {
                method: options.method || 'GET',
                headers: {
                    ...this.defaultHeaders,
                    ...options.headers
                },
                ...options
            };

            // Add body for POST/PUT/PATCH requests
            if (options.body && typeof options.body === 'object' && !(options.body instanceof FormData)) {
                requestOptions.body = JSON.stringify(options.body);
            }

            // Show loading toast if specified
            if (options.showLoading) {
                this.showToast('Processing request...', 'info', 'Loading', 2000);
            }

            // Make the request
            const response = await fetch(url, requestOptions);
            let data = {};

            // Parse response
            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                data = await response.json();
            } else {
                const text = await response.text();
                if (text) {
                    try {
                        data = JSON.parse(text);
                    } catch {
                        data = { message: text };
                    }
                }
            }

            // Handle response and show toast
            return this.handleResponse(response, data, options.messages);

        } catch (error) {
            console.error('API Request Error:', error);
            const errorMessage = options.messages?.error || 'Network error occurred. Please check your connection.';
            this.showToast(errorMessage, 'error');
            return { success: false, error: error.message };
        }
    }

    /**
     * GET request
     */
    async get(url, options = {}) {
        return await this.request(url, { ...options, method: 'GET' });
    }

    /**
     * POST request
     */
    async post(url, body = {}, options = {}) {
        return await this.request(url, { ...options, method: 'POST', body });
    }

    /**
     * PUT request
     */
    async put(url, body = {}, options = {}) {
        return await this.request(url, { ...options, method: 'PUT', body });
    }

    /**
     * DELETE request
     */
    async delete(url, options = {}) {
        return await this.request(url, { ...options, method: 'DELETE' });
    }

    /**
     * PATCH request
     */
    async patch(url, body = {}, options = {}) {
        return await this.request(url, { ...options, method: 'PATCH', body });
    }

    /**
     * Form submission helper
     */
    async submitForm(form, options = {}) {
        const formData = new FormData(form);
        const url = options.url || form.action;
        const method = options.method || form.method || 'POST';

        return await this.request(url, {
            method: method.toUpperCase(),
            body: formData,
            headers: {
                'X-CSRFToken': this.csrfToken
            },
            ...options
        });
    }

    /**
     * File upload helper
     */
    async uploadFile(url, fileInput, additionalData = {}, options = {}) {
        const formData = new FormData();
        
        if (fileInput.files.length > 0) {
            Array.from(fileInput.files).forEach((file, index) => {
                formData.append(`file_${index}`, file);
            });
        }

        Object.keys(additionalData).forEach(key => {
            formData.append(key, additionalData[key]);
        });

        return await this.request(url, {
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRFToken': this.csrfToken
            },
            showLoading: true,
            messages: {
                success: 'File uploaded successfully',
                error: 'File upload failed'
            },
            ...options
        });
    }

    /**
     * Batch API requests
     */
    async batch(requests) {
        const results = await Promise.allSettled(
            requests.map(req => this.request(req.url, req.options))
        );

        const successful = results.filter(r => r.status === 'fulfilled' && r.value.success).length;
        const failed = results.length - successful;

        if (failed === 0) {
            this.showToast(`All ${successful} operations completed successfully`, 'success');
        } else if (successful === 0) {
            this.showToast(`All ${failed} operations failed`, 'error');
        } else {
            this.showToast(`${successful} succeeded, ${failed} failed`, 'warning');
        }

        return results;
    }

    /**
     * Retry mechanism for failed requests
     */
    async requestWithRetry(url, options = {}, maxRetries = 3) {
        let lastError;
        
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                const result = await this.request(url, options);
                if (result.success) {
                    return result;
                }
                lastError = result.error;
            } catch (error) {
                lastError = error.message;
                if (attempt < maxRetries) {
                    await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
                }
            }
        }

        this.showToast(`Failed after ${maxRetries} attempts: ${lastError}`, 'error');
        return { success: false, error: lastError };
    }
}

// Create global instance
window.apiManager = new APIManager();

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = APIManager;
}

// jQuery integration (if available)
if (typeof $ !== 'undefined') {
    $.apiManager = window.apiManager;
}

console.log('🚀 API Manager loaded and ready to use globally as window.apiManager');