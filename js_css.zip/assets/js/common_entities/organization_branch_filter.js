/**
 * Organization-Branch Dependent Dropdown Handler
 * Handles automatic filtering of branches when organization changes
 * 
 * Usage:
 * 1. Include this script in your template
 * 2. Call initOrganizationBranchFilter() when DOM is ready
 * 3. Ensure your HTML has: 
 *    - Organization select with id="organization"
 *    - Branch select with id="branch"
 *    - Branch options with data-organization-id attribute
 */

/**
 * Initialize organization-branch filtering
 * @param {string} organizationSelectId - ID of organization select element (default: 'organization')
 * @param {string} branchSelectId - ID of branch select element (default: 'branch')
 * @param {boolean} clearOnChange - Whether to clear branch selection when org changes (default: true)
 */
function initOrganizationBranchFilter(organizationSelectId = 'organization', branchSelectId = 'branch', clearOnChange = true) {
    const orgSelect = document.getElementById(organizationSelectId);
    const branchSelect = document.getElementById(branchSelectId);
    
    if (!orgSelect || !branchSelect) {
        console.warn('Organization or Branch select not found. IDs:', organizationSelectId, branchSelectId);
        return;
    }
    
    // Store all branch options
    const allBranchOptions = Array.from(branchSelect.options).filter(option => option.value !== '');
    
    // Function to filter branches based on selected organization
    function filterBranches() {
        const selectedOrgId = orgSelect.value;
        
        // Clear current branch options (except the placeholder)
        const placeholder = branchSelect.querySelector('option[value=""]');
        branchSelect.innerHTML = '';
        if (placeholder) {
            branchSelect.appendChild(placeholder.cloneNode(true));
        }
        
        if (!selectedOrgId || selectedOrgId === 'all' || selectedOrgId === '') {
            // If no organization selected, show all branches or none
            if (!clearOnChange) {
                allBranchOptions.forEach(option => {
                    branchSelect.appendChild(option.cloneNode(true));
                });
            } else {
                // Show message when no organization is selected
                const noOrgOption = document.createElement('option');
                noOrgOption.value = '';
                noOrgOption.textContent = 'Please select an organization first';
                noOrgOption.disabled = true;
                branchSelect.appendChild(noOrgOption);
            }
            return;
        }
        
        // Filter and add branches that belong to the selected organization
        const filteredBranches = allBranchOptions.filter(option => {
            const orgId = option.getAttribute('data-organization-id');
            return orgId && orgId === selectedOrgId;
        });
        
        if (filteredBranches.length === 0) {
            // No branches available for this organization
            const noBranchOption = document.createElement('option');
            noBranchOption.value = '';
            noBranchOption.textContent = 'No branches available for this organization';
            noBranchOption.disabled = true;
            branchSelect.appendChild(noBranchOption);
        } else {
            // Add filtered branches
            filteredBranches.forEach(option => {
                branchSelect.appendChild(option.cloneNode(true));
            });
        }
        
        // Reset selection if clearOnChange is true
        if (clearOnChange) {
            branchSelect.value = '';
        }
    }
    
    // Attach event listener to organization select
    orgSelect.addEventListener('change', filterBranches);
    
    // Initial filter on page load
    filterBranches();
    
    console.log('✅ Organization-Branch filter initialized successfully');
}

/**
 * Fetch branches dynamically from API based on organization
 * Use this when branches are not pre-loaded in HTML
 * @param {string} organizationId - Organization ID
 * @param {string} branchSelectId - ID of branch select element
 */
async function loadBranchesByOrganization(organizationId, branchSelectId = 'branch') {
    const branchSelect = document.getElementById(branchSelectId);
    
    if (!branchSelect) {
        console.error('Branch select not found:', branchSelectId);
        return;
    }
    
    if (!organizationId || organizationId === 'all' || organizationId === '') {
        // Clear branches
        const placeholder = branchSelect.querySelector('option[value=""]');
        branchSelect.innerHTML = '';
        if (placeholder) {
            branchSelect.appendChild(placeholder.cloneNode(true));
        }
        return;
    }
    
    try {
        // Show loading state
        branchSelect.disabled = true;
        branchSelect.innerHTML = '<option value="">Loading branches...</option>';
        
        // Make API call to fetch branches
        const response = await apiManager.get(`/api/branches/by-organization/?organization_id=${organizationId}`);
        
        if (response.success && response.data) {
            const branches = response.data.branches || [];
            
            // Clear and repopulate
            branchSelect.innerHTML = '<option value="">Select Branch (Optional)</option>';
            
            if (branches.length === 0) {
                const noBranchOption = document.createElement('option');
                noBranchOption.value = '';
                noBranchOption.textContent = 'No branches available';
                noBranchOption.disabled = true;
                branchSelect.appendChild(noBranchOption);
            } else {
                branches.forEach(branch => {
                    const option = document.createElement('option');
                    option.value = branch.id;
                    option.textContent = branch.name;
                    option.setAttribute('data-organization-id', organizationId);
                    branchSelect.appendChild(option);
                });
            }
        } else {
            console.error('Failed to load branches:', response.error);
            branchSelect.innerHTML = '<option value="">Error loading branches</option>';
        }
    } catch (error) {
        console.error('Error fetching branches:', error);
        branchSelect.innerHTML = '<option value="">Error loading branches</option>';
    } finally {
        branchSelect.disabled = false;
    }
}

/**
 * Advanced initialization with API-based loading
 * @param {string} organizationSelectId - ID of organization select element
 * @param {string} branchSelectId - ID of branch select element
 * @param {boolean} useAPI - Whether to fetch branches from API (default: false)
 */
function initOrganizationBranchFilterAdvanced(organizationSelectId = 'organization', branchSelectId = 'branch', useAPI = false) {
    const orgSelect = document.getElementById(organizationSelectId);
    
    if (!orgSelect) {
        console.warn('Organization select not found:', organizationSelectId);
        return;
    }
    
    if (useAPI) {
        // API-based loading
        orgSelect.addEventListener('change', function() {
            loadBranchesByOrganization(this.value, branchSelectId);
        });
        
        // Load initial branches
        if (orgSelect.value) {
            loadBranchesByOrganization(orgSelect.value, branchSelectId);
        }
    } else {
        // Client-side filtering (default)
        initOrganizationBranchFilter(organizationSelectId, branchSelectId);
    }
}

// Auto-initialize on DOM ready if data attribute is present
document.addEventListener('DOMContentLoaded', function() {
    // Look for elements with data-auto-init attribute
    const autoInitElements = document.querySelectorAll('[data-org-branch-filter="auto"]');
    
    autoInitElements.forEach(element => {
        const orgSelectId = element.getAttribute('data-org-select-id') || 'organization';
        const branchSelectId = element.getAttribute('data-branch-select-id') || 'branch';
        const useAPI = element.getAttribute('data-use-api') === 'true';
        
        initOrganizationBranchFilterAdvanced(orgSelectId, branchSelectId, useAPI);
    });
});
