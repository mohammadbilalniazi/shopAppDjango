/**
 * API Endpoints Configuration
 * Centralized configuration for all API endpoints in the Django Shop Application
 */

const API_ENDPOINTS = {
    // Base URLs
    BASE: '',
    
    // Authentication & User Management
    AUTH: {
        LOGIN: '/host_to_heroku_login_form/submit/',
        LOGOUT: '/admin/logout/',
        PROFILE: '/user/profile/',
        DASHBOARD: '/user/dashboard/'
    },

    // User Management
    USER: {
        LIST: '/user/organization_user/get/',
        CREATE: '/user/organization_user/insert/',
        UPDATE: '/user/organization_user/insert/',
        DELETE: '/user/organization_user/delete/',
        SEARCH: '/user/organization_user/search/',
        GROUPS: '/user/groups/',
        GROUP_CREATE: '/user/groups/create-update/',
        GROUP_DELETE: '/user/groups/delete/',
        SESSIONS: '/user/sessions/',
        SESSION_DELETE: '/user/sessions/delete/',
        SESSION_CLEAR: '/user/sessions/clear-expired/'
    },

    // Organizations & Configuration
    ORGANIZATION: {
        LIST: '/admin/configuration/organization/',
        CREATE: '/configuration/organization/form/create/',
        UPDATE: '/configuration/organization/form/create/',
        DETAIL: '/organizations/',
        USER_ORGS: '/organizations/user/'
    },

    // Branch Management
    BRANCH: {
        LIST: '/configuration/branch/',
        CREATE: '/configuration/branch/create/',
        UPDATE: '/configuration/branch/update/',
        DELETE: '/configuration/branch/delete/',
        DETAIL: '/configuration/branch/detail/',
        TOGGLE_STATUS: '/configuration/branch/toggle-status/',
        BY_ORGANIZATION: '/api/branches/by-organization/',
        USER_ACCESSIBLE: '/api/branches/user-accessible/',
        ORGANIZATION_USERS: '/configuration/organization/users/'
    },

    // Product Management
    PRODUCT: {
        LIST: '/products/',
        LIST_HTML: '/admin/product/product/',
        CREATE: '/admin/product/product/add/',
        UPDATE: '/product/product_form/create/',
        SEARCH: '/products/',
        CATEGORY_CREATE: '/api/category/create/'
    },

    // Stock Management
    STOCK: {
        LIST: '/stock/list/',
        UPDATE: '/stock/update/'
    },

    // Bill Management
    BILL: {
        LIST: '/admin/bill/bill/',
        CREATE: '/admin/bill/bill/add/',
        DETAIL: '/bill/detail/',
        DELETE: '/bill/delete/',
        SEARCH: '/bill/search/',
        INSERT: '/bill/insert/',
        RECEIVE_PAYMENT: '/receive_payment/bill/',
        RECEIVE_PAYMENT_SAVE: '/receive_payment/bill/save/',
        SELECT_BILL_NO: '/bill/select_bill_no/',
        BILL_DETAIL_DELETE: '/bill/detail/delete/',
        FINALIZE_LEDGER: '/organizations/finalize-ledger'
    },

    // Asset Management
    ASSET: {
        DASHBOARD: '/asset/',
        CALCULATE_PURCHASED: '/organizations/calculate-purchased-asset-from-products-using'
    },

    // Expenditure
    EXPENDITURE: {
        FORM: '/expenditure/bill/form/',
        INSERT: '/expenditure/bill/insert/'
    },

    // Location & Countries
    LOCATION: {
        COUNTRIES: '/configuration/countries/',
        LIST: '/configuration/location/',
        DETAIL: '/configuration/location/'
    },

    // Units
    UNIT: {
        DETAIL: '/units/'
    }
};

// Helper functions for dynamic URLs
const API_HELPERS = {
    // User Management
    getUserById: (id) => `${API_ENDPOINTS.USER.LIST}${id}`,
    deleteUser: (id) => `${API_ENDPOINTS.USER.DELETE}${id}`,
    updateUser: (id) => `${API_ENDPOINTS.USER.UPDATE}${id}`,
    
    // Groups
    groupForm: (id) => `${API_ENDPOINTS.USER.GROUPS}form/${id}/`,
    deleteGroup: (id) => `${API_ENDPOINTS.USER.GROUP_DELETE}${id}/`,
    
    // Sessions
    deleteSession: (sessionKey) => `${API_ENDPOINTS.USER.SESSION_DELETE}${sessionKey}/`,
    
    // Organization
    organizationDetail: (id) => `${API_ENDPOINTS.ORGANIZATION.DETAIL}${id}/`,
    organizationForm: (id) => `${API_ENDPOINTS.ORGANIZATION.CREATE}${id}`,
    
    // Branch Management
    branchManagement: (orgId) => `${API_ENDPOINTS.BRANCH.LIST}organization/${orgId}/`,
    branchUpdate: (branchId) => `${API_ENDPOINTS.BRANCH.UPDATE.replace('/update/', `/${branchId}/update/`)}`,
    branchDelete: (branchId) => `${API_ENDPOINTS.BRANCH.DELETE.replace('/delete/', `/${branchId}/delete/`)}`,
    branchDetail: (branchId) => `${API_ENDPOINTS.BRANCH.DETAIL.replace('/detail/', `/${branchId}/detail/`)}`,
    branchToggleStatus: (branchId) => `${API_ENDPOINTS.BRANCH.TOGGLE_STATUS.replace('/toggle-status/', `/${branchId}/toggle-status/`)}`,
    branchesByOrganization: (orgId) => `${API_ENDPOINTS.BRANCH.BY_ORGANIZATION}${orgId}/`,
    organizationUsers: (orgId) => `${API_ENDPOINTS.BRANCH.ORGANIZATION_USERS.replace('/users/', `/${orgId}/users/`)}`,
    
    // Products
    productForm: (id) => `${API_ENDPOINTS.PRODUCT.CREATE}${id ? `/${id}` : ''}`,
    productUpdate: (id) => `${API_ENDPOINTS.PRODUCT.UPDATE}${id}`,
    
    // Bills
    billDetail: (billId) => `${API_ENDPOINTS.BILL.DETAIL}${billId}/`,
    billDelete: (id) => `${API_ENDPOINTS.BILL.DELETE}${id}/`,
    billDetailDelete: (billDetailId) => `${API_ENDPOINTS.BILL.BILL_DETAIL_DELETE}${billDetailId}`,
    selectBillNo: (orgId, billRcvrOrgId, billType) => `${API_ENDPOINTS.BILL.SELECT_BILL_NO}${orgId}/${billRcvrOrgId}/${billType}`,
    expenditureForm: (id) => `${API_ENDPOINTS.EXPENDITURE.FORM}${id ? `/${id}` : ''}`,
    
    // Location
    locationDetail: (id) => `${API_ENDPOINTS.LOCATION.DETAIL}${id}/`,
    
    // Units
    unitDetail: (id) => `${API_ENDPOINTS.UNIT.DETAIL}${id}/`
};

// Export for use
if (typeof window !== 'undefined') {
    window.API_ENDPOINTS = API_ENDPOINTS;
    window.API_HELPERS = API_HELPERS;
}

if (typeof module !== 'undefined' && module.exports) {
    module.exports = { API_ENDPOINTS, API_HELPERS };
}

console.log('📍 API Endpoints configuration loaded');