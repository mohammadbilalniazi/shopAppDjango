Product Module Documentation

1. Module Scope

The product module handles:
- Product master data
- Category creation
- Product detail settings per organization
- Product form rendering and update flow
- Integration with stock rows

Primary files:
- product/models.py
- product/views_product.py
- product/serializer.py
- shop/urls.py

2. Main Data Models

Category

```python
class Category(models.Model):
    parent = models.ForeignKey("self", on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=30,null=False, blank=False,unique=True)
    description=models.TextField(max_length=100,null=True,blank=True)
    img=models.ImageField(upload_to = Category_directory_path,null=True,blank=True)
    is_active=models.BooleanField(default=True)
```

Product

```python
class Product(models.Model):
    item_name = models.CharField(max_length=50, null=False, blank=False)
    category = models.ForeignKey(Category, on_delete=models.DO_NOTHING, default=None)
    model = models.CharField(max_length=20, null=True, blank=True)
    barcode = models.CharField(max_length=25, null=True, blank=True, unique=True)
    serial_no = models.CharField(max_length=25, null=True, blank=True, unique=True)
    img = models.ImageField(upload_to='Products', null=True, blank=True)
    is_service = models.BooleanField(default=False)

    class Meta:
        unique_together=("item_name","model")
```

Product_Detail
Product attributes bound to organization and branch context.

```python
class Product_Detail(models.Model):
    product=models.OneToOneField(Product,on_delete=models.CASCADE,null=True,blank=True,unique=True)
    organization=models.ForeignKey(Organization,on_delete=models.DO_NOTHING,default=None,blank=True,null=True)
    branch=models.ForeignKey('configuration.Branch',on_delete=models.SET_NULL,null=True,blank=True)
    minimum_requirement=models.IntegerField(default=1)
    purchased_price= models.DecimalField(default=0,max_digits=22, decimal_places=2,null=True)
    selling_price=models.DecimalField(default=0,max_digits=22, decimal_places=2,null=True)
```

3. Product Create/Update Flow

From product/views_product.py:

```python
@login_required(login_url='/admin')
@api_view(('PUT', 'POST'))
@transaction.atomic
def create(request, id=None):
    product = {
        "id": data.get("id"),
        "img": request.FILES.get("img", None),
        "item_name": data.get("item_name"),
        "category": get_object_or_404(Category, id=int(data["category"])),
        "model": data.get("model", ""),
        "is_service": data.get("is_service") == "on"
    }
```

Important steps in this function:
- validate and resolve selected organization
- optionally resolve selected branch
- insert or update Product
- insert or update Product_Detail
- insert or update Stock row

4. Product Listing Behavior

API listing from product/views_product.py:

```python
@api_view(['POST'])
def show(request):
    item_name=request.data.get("item_name",None)
    organization_id = request.data.get("organization", None)

    self_organization, user_orgs = find_userorganization(request, organization_id)

    if organization_id is None:
        query_set=Product.objects.order_by('-pk')
    else:
        if self_organization is not None:
            query_set=Product.objects.filter(product_detail__organization=self_organization)
        else:
            query_set=Product.objects.filter(product_detail__organization__in=user_orgs)
```

This provides tenant-aware filtering of product records.

5. Category Creation API

From product/views_product.py:

```python
@api_view(['POST'])
def create_category(request):
    name = request.data.get('name', '').strip()

    if not name:
        return Response({'ok': False, 'message': 'Category name is required'}, status=400)

    if Category.objects.filter(name=name).exists():
        return Response({'ok': False, 'message': f'Category "{name}" already exists'}, status=400)

    category = Category.objects.create(...)
```

6. Main Routes

Registered in shop/urls.py:

```python
path('products/', views_product.show, name='product_show')
path('products/product_form/', views_product.form, name='product_form')
path('products/product/add/<id>', views_product.form, name='product_form')
path('product/product_form/create/', views_product.create, name='product_form_create')
path('product/product_form/create/<id>', views_product.create, name='product_form_update')
path('api/category/create/', views_product.create_category, name='create_category_api')
```

7. Thesis Discussion Points

1. Explain two-level design: Product (master) and Product_Detail (organization context).
2. Discuss image handling and model-level uniqueness constraints.
3. Show product lifecycle integration with inventory stock creation.
4. Compare form-based HTML flow and JSON API flow in the same module.
