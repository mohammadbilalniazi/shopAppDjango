Product Module Documentation

Purpose

This document explains the product-management design of the supermarket electronic management system. It is intended for thesis use and focuses on the product data model, category structure, organization-aware product details, and the relationship between products and stock.

Module Scope

The product module is implemented mainly in product/models.py, product/views_product.py, product/views_stock.py, and shop/urls.py. It supports product registration, category assignment, product-detail configuration, optional branch linkage, and integration with stock rows.

Core Data Structures

The Category model provides a simple hierarchical classification structure through a self-referential parent field. Each category stores its name, description, optional image, and activation state. This makes category records useful for grouping products into business-relevant classes.

The Product model stores the product master record. It includes item name, category, model, barcode, serial number, optional image, and the is_service flag. The model uses a uniqueness rule on item name and model so that the same product variant is not duplicated unnecessarily.

The Product_Detail model extends the master product with organization-specific information. It stores the organization, optional branch, minimum stock requirement, purchased price, selling price, and unit. This design is important because a product can be treated as a global item while still carrying organization-specific commercial settings.

Workflow

The product create and update workflow begins in product/views_product.py. The user submits product fields together with pricing and organization context. The backend validates the selected category, resolves the selected organization, optionally validates the branch, and then inserts or updates the Product record. After this, the system inserts or updates Product_Detail and ensures that a corresponding Stock record exists.

This workflow is technically significant because it prevents product creation from becoming detached from inventory state. Product registration and stock initialization are treated as linked operations inside one transaction-aware flow.

Listing Behavior

The product listing API supports organization-aware filtering. Users can retrieve products generally or limit the result set to products associated with their accessible organizations. This is consistent with the multi-tenant design used across the wider application.

Category Creation

The module also includes a category-creation API. The endpoint validates category name presence, checks uniqueness, optionally resolves a parent category, and then creates the category. This allows categories to be extended through the interface without direct database maintenance.

Routes

The main routes are:
- /products/ for product listing
- /products/product_form/ for the product form
- /product/product_form/create/ for product creation
- /product/product_form/create/<id> for product update
- /api/category/create/ for category creation
- /stock/update/ for direct stock updates
- /stock/list/ for stock listing

Business Importance

The product module forms the bridge between catalog management and inventory control. It stores the commercial definition of an item while also supporting branch-aware availability, pricing, and stock behavior. Because of this, it is one of the central modules in the overall supermarket management system.

Thesis Value

This module is useful in a thesis because it demonstrates layered product design. The distinction between Product and Product_Detail shows how global master data can be combined with organization-specific operational data. It also provides a concrete example of integrating catalog management with stock initialization and branch-aware business logic.
